"""SSO 认证中间件。

认证优先级（从高到低）：
  1. Cookie ticket   → SSO 服务端验证 ticket，获取用户信息
  2. Query code      → SSO OAuth 回调，code 换 ticket，写 Cookie
  3. MCP Header      → MCP Gateway 签名认证，从 x-user-context 提取用户
  4. 兜底            → 返回 401 + SSO 登录 URL

豁免路径通过 skip_paths / skip_prefixes 构造函数参数配置。
设置 enabled=False 可全局禁用认证（本地开发便利）。
"""
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from ._logger import log_biz
from .mcp_auth import McpAuthService
from .models import User
from .sso_service import SsoService
from .user_context import clear_user, set_user

_DEFAULT_SKIP_PATHS: frozenset[str] = frozenset([
    "/api/health",
    "/openapi.json",
    "/docs",
    "/redoc",
])
_DEFAULT_SKIP_PREFIXES: tuple[str, ...] = ("/docs/", "/redoc/")


class SsoMiddleware(BaseHTTPMiddleware):
    """Starlette 中间件：对所有非豁免路径强制执行 SSO / MCP 认证。"""

    def __init__(
        self,
        app,
        *,
        sso_service: SsoService,
        mcp_auth: McpAuthService,
        enabled: bool = True,
        default_user: User | None = None,
        skip_paths: frozenset[str] | None = None,
        skip_prefixes: tuple[str, ...] | None = None,
    ) -> None:
        """
        Args:
            app:           ASGI 应用实例
            sso_service:   SSO ticket/code 校验服务
            mcp_auth:      MCP Gateway 签名校验服务
            enabled:       False 时全局跳过认证（本地开发用）
            default_user:  SSO 禁用时写入 ContextVar 的默认用户
            skip_paths:    精确匹配豁免路径（默认: /api/health /openapi.json /docs /redoc）
            skip_prefixes: 前缀匹配豁免路径（默认: /docs/ /redoc/）
        """
        super().__init__(app)
        self.sso = sso_service
        self.mcp = mcp_auth
        self.enabled = enabled
        self.default_user = default_user
        self._skip_paths = skip_paths if skip_paths is not None else _DEFAULT_SKIP_PATHS
        self._skip_prefixes = skip_prefixes if skip_prefixes is not None else _DEFAULT_SKIP_PREFIXES

    async def dispatch(self, request: Request, call_next) -> Response:
        if not self.enabled or self._is_skip_path(request):
            if self.default_user is not None:
                return await self._proceed(request, call_next, self.default_user)
            return await call_next(request)

        # 优先级 1：Cookie ticket
        ticket = self.sso.get_ticket(dict(request.cookies))
        if ticket:
            log_biz("_sso_auth", level="DEBUG", action="ticket_check", uri=request.url.path)
            valid = await self.sso.check_ticket(ticket)
            if valid:
                user = await self.sso.get_user_info(ticket)
                if user:
                    return await self._proceed(request, call_next, user)
                log_biz("_sso_auth", level="ERROR", action="get_user_info", errno=-1, errmsg="ticket valid but user info fetch failed")
            else:
                log_biz("_sso_auth", level="WARNING", action="ticket_check", errno=-1, errmsg="ticket invalid")

        # 优先级 2：OAuth code 换 ticket
        code = request.query_params.get("code")
        if code:
            log_biz("_sso_auth", level="DEBUG", action="code_exchange", uri=request.url.path)
            data = await self.sso.check_code(code)
            if data:
                ticket = data.get("ticket", "")
                if ticket:
                    user = await self.sso.get_user_info(ticket)
                    if user:
                        set_user(user)
                        response = await call_next(request)
                        clear_user()
                        self.sso.set_ticket_cookie(response, ticket)
                        return response

        # 优先级 3：MCP Gateway 签名
        if self.mcp.is_mcp_request(request.headers):
            log_biz("_sso_mcp_auth", level="DEBUG", action="mcp_request", uri=request.url.path)
            try:
                user = self.mcp.check_mcp_auth(request.headers)
                return await self._proceed(request, call_next, user)
            except ValueError as exc:
                log_biz("_sso_mcp_auth", level="ERROR", errno=-1, errmsg=str(exc)[:500])
                return JSONResponse({"detail": str(exc)}, status_code=401)

        # 兜底：未认证，返回 401 + 登录 URL
        referer = request.headers.get("referer", "")
        login_url = self.sso.get_login_url(referer)
        log_biz("_sso_auth", level="DEBUG", action="redirect_to_login", uri=request.url.path)
        return JSONResponse({"loginUrl": login_url}, status_code=401)

    async def _proceed(self, request: Request, call_next, user: User) -> Response:
        set_user(user)
        try:
            return await call_next(request)
        finally:
            clear_user()

    def _is_skip_path(self, request: Request) -> bool:
        path = request.url.path
        if path in self._skip_paths:
            return True
        return any(path.startswith(prefix) for prefix in self._skip_prefixes)
