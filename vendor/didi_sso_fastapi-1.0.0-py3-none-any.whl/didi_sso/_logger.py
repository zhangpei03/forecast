"""SSO 包内部日志工具，封装标准 logging，兼容 dltag 格式。

调用方通过配置 logging.getLogger("didi_sso") 来控制日志级别和输出目标。
"""
import logging

_logger = logging.getLogger("didi_sso")


def log_biz(dltag: str, level: str = "INFO", **kwargs) -> None:
    """记录 DLTAG 格式业务日志。

    Args:
        dltag:  日志标签（如 "_sso_auth"）
        level:  日志级别字符串，支持 DEBUG/INFO/WARNING/ERROR（大小写均可）
        **kwargs: 附加键值对，格式化为 ||k=v 追加到消息末尾
    """
    msg = dltag + "".join(f"||{k}={v}" for k, v in kwargs.items())
    log_fn = getattr(_logger, level.lower(), _logger.info)
    log_fn(msg)
