"""SSO 相关数据模型。"""
from dataclasses import dataclass


@dataclass
class User:
    """SSO 认证后的用户信息。"""
    id: str = ""
    ldap: str = ""        # LDAP 账号（英文），如 zhangsan；对应 JSON 字段 username
    user_name: str = ""   # 中文姓名，如 张三；对应 JSON 字段 username_zh
    email: str = ""
    phone: str = ""
    area: str = ""
    active: str = ""      # 账号是否激活；对应 JSON 字段 is_active
    department: str = ""  # 一级部门；对应 JSON 字段 dep_1
    title: str = ""
    admin: str = ""       # 是否管理员；对应 JSON 字段 is_admin

    @classmethod
    def from_dict(cls, data: dict) -> "User":
        """从 SSO API 原始响应字典构造 User 实例。"""
        return cls(
            id=data.get("id", ""),
            ldap=data.get("username", ""),
            user_name=data.get("username_zh", ""),
            email=data.get("email", ""),
            phone=data.get("phone", ""),
            area=data.get("area", ""),
            active=str(data.get("is_active", "")),
            department=data.get("dep_1", ""),
            title=data.get("title", ""),
            admin=str(data.get("is_admin", "")),
        )


@dataclass
class McpUserContext:
    """MCP Gateway 在 x-user-context Header 中携带的用户上下文。"""
    ldap: str = ""
    user_name: str = ""    # 对应 JSON 字段 userName（驼峰命名）
    tenant_code: str = ""  # 租户标识；对应 JSON 字段 tenantCode
    timestamp: int = 0     # 毫秒时间戳，用于防重放校验

    @classmethod
    def from_dict(cls, data: dict) -> "McpUserContext":
        """从解码后的 JSON 字典构造 McpUserContext。"""
        return cls(
            ldap=data.get("ldap", ""),
            user_name=data.get("userName", ""),
            tenant_code=data.get("tenantCode", ""),
            timestamp=int(data.get("timestamp", 0)),
        )
