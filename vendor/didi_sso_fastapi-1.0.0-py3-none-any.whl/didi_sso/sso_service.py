"""SSO 核心服务：ticket/code 校验、用户信息拉取、Cookie 管理、URL 构建。

两种运行模式（由 mock 参数控制）：
  mock=False（默认，生产环境）: 调用 UPM 接口验证 ticket 并拉取用户信息
  mock=True（测试/开发环境）:  调用 Mock SSO 接口，以 access_token 参数传递 ticket

Cookie 命名策略：
  - 有 domain 时用通用名 "_sso_ticket"（跨子域共享，单点登录）
  - 无 domain 时用 "_sso_ticket_{app_id}"（隔离不同应用）
"""
import time
from urllib.parse import quote

import httpx

from ._logger import log_biz
from .constants import (
    SSO_TICKET,
    SSO_ERRNO,
    SSO_ERRNO_SUCCESS,
    SSO_DATA,
)
from .models import User


class SsoService:
    """SSO 核心服务：ticket/code 校验、用户信息拉取、Cookie 管理、URL 构建。"""

    def __init__(
        self,
        *,
        app_id: str,
        app_key: str,
        sso_host: str,
        domain: str = "",
        login_path: str = "/auth/sso/login",
        logout_path: str = "/auth/ldap/logout",
        check_ticket_path: str = "/auth/sso/api/check_ticket",
        check_code_path: str = "/auth/sso/api/check_code",
        mock: bool = False,
        user_index_path: str = "/auth/api/user/index",
        upm_check_user_ticket_path: str = "",
        http_timeout: float = 5.0,
    ) -> None:
        """
        Args:
            app_id:                      SSO 应用 ID
            app_key:                     SSO 应用密钥（code 换 ticket 时使用）
            sso_host:                    SSO 服务主机，如 "https://mis.diditaxi.com.cn"
            domain:                      Cookie 作用域，如 ".diditaxi.com.cn"；空字符串表示当前域
            login_path:                  SSO 登录页路径
            logout_path:                 SSO 登出路径
            check_ticket_path:           ticket 校验接口路径
            check_code_path:             OAuth code 换 ticket 接口路径
            mock:                        True 时使用 Mock SSO 模式（测试环境）
            user_index_path:             Mock 模式的用户信息接口路径
            upm_check_user_ticket_path:  UPM 模式的用户信息接口路径
            http_timeout:                HTTP 请求超时秒数
        """
        self.app_id = app_id
        self.app_key = app_key
        self.sso_host = sso_host.rstrip("/")
        self.domain = domain
        self.login_path = login_path
        self.logout_path = logout_path
        self.check_ticket_path = check_ticket_path
        self.check_code_path = check_code_path
        self.mock = mock
        self.user_index_path = user_index_path
        self.upm_check_user_ticket_path = upm_check_user_ticket_path
        self._timeout = http_timeout

    # ── Cookie 管理 ──────────────────────────────────────────────────────────

    def _ticket_cookie_name(self) -> str:
        if not self.domain:
            return f"{SSO_TICKET}_{self.app_id}"
        return SSO_TICKET

    def get_ticket(self, cookies: dict) -> str:
        return cookies.get(self._ticket_cookie_name(), "")

    def set_ticket_cookie(self, response, ticket: str) -> None:
        """在响应中写入 ticket Cookie（4 小时有效，httponly，samesite=lax）。"""
        max_age = 60 * 60 * 4
        kwargs: dict = {"max_age": max_age, "httponly": True, "samesite": "lax"}
        if self.domain:
            kwargs["domain"] = self.domain
        response.set_cookie(self._ticket_cookie_name(), ticket, **kwargs)

    def remove_ticket_cookie(self, response) -> None:
        response.delete_cookie(self._ticket_cookie_name())

    # ── URL 构建 ─────────────────────────────────────────────────────────────

    def get_login_url(self, jump_to: str = "") -> str:
        params = f"app_id={self.app_id}&version=1.0"
        if jump_to:
            params += f"&jumpto={quote(jump_to, safe='')}"
        return f"{self.sso_host}{self.login_path}?{params}"

    def get_logout_url(self, jump_to: str = "") -> str:
        params = f"app_id={self.app_id}"
        if jump_to:
            params += f"&jumpto={quote(jump_to, safe='')}"
        return f"{self.sso_host}{self.logout_path}?{params}"

    # ── SSO 远程调用 ─────────────────────────────────────────────────────────

    async def check_ticket(self, ticket: str) -> bool:
        """调用 SSO 服务端验证 ticket 是否有效。"""
        url = self.sso_host + self.check_ticket_path
        payload = {"ticket": ticket, "app_id": self.app_id}
        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                resp = await client.post(url, data=payload)
                resp.raise_for_status()
                body = resp.json()
                return body.get(SSO_ERRNO, -1) == SSO_ERRNO_SUCCESS
        except Exception as exc:
            log_biz("_sso_auth", level="ERROR", action="check_ticket", errno=-1, errmsg=str(exc)[:500])
            return False

    async def check_code(self, code: str) -> dict | None:
        """用 OAuth code 换取 SSO ticket。"""
        url = self.sso_host + self.check_code_path
        payload = {"code": code, "app_id": self.app_id, "app_key": self.app_key}
        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                resp = await client.post(url, data=payload)
                resp.raise_for_status()
                body = resp.json()
                if body.get(SSO_ERRNO, -1) == SSO_ERRNO_SUCCESS:
                    return body.get(SSO_DATA)
        except Exception as exc:
            log_biz("_sso_auth", level="ERROR", action="check_code", errno=-1, errmsg=str(exc)[:500])
        return None

    async def get_user_info(self, ticket: str) -> User | None:
        """拉取用户详细信息，失败时最多重试 3 次（50ms 间隔）。"""
        for attempt in range(1, 4):
            try:
                user = await self._fetch_user(ticket)
                if user is not None:
                    return user
                log_biz("_sso_auth", level="WARNING", action="get_user_info", attempt=attempt, errmsg="returned None")
                await _sleep_ms(50)
            except Exception as exc:
                log_biz("_sso_auth", level="ERROR", action="get_user_info", attempt=attempt, errno=-1, errmsg=str(exc)[:500])
                raise
        log_biz("_sso_auth", level="ERROR", action="get_user_info", errno=-1, errmsg="3 retries exhausted")
        return None

    async def _fetch_user(self, ticket: str) -> User | None:
        if self.mock:
            return await self._fetch_user_mock(ticket)
        return await self._fetch_user_upm(ticket)

    async def _fetch_user_upm(self, ticket: str) -> User | None:
        """UPM 模式：调用 UPM ticket 接口同时校验并拉取用户信息。"""
        path = self.upm_check_user_ticket_path or self.user_index_path
        url = self.sso_host + path
        payload = {"ticket": ticket, "app_id": self.app_id}
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.post(url, data=payload)
            resp.raise_for_status()
            body = resp.json()
            errno = body.get(SSO_ERRNO, -1)
            if errno != SSO_ERRNO_SUCCESS:
                raise RuntimeError(f"SSO getUserInfo error: {body.get('errmsg', '')}")
            data = body.get(SSO_DATA)
            if data is None:
                return None
            return User.from_dict(data)

    async def _fetch_user_mock(self, ticket: str) -> User | None:
        """Mock 模式：ticket 以 access_token 传参，data 下有额外的 user 子字典。"""
        url = self.sso_host + self.user_index_path
        payload = {"access_token": ticket}
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.post(url, data=payload)
            resp.raise_for_status()
            body = resp.json()
            data = body.get(SSO_DATA)
            if data is None:
                return None
            user_data = data.get("user") if isinstance(data, dict) else None
            if user_data is None:
                return None
            return User.from_dict(user_data)


async def _sleep_ms(ms: int) -> None:
    import asyncio
    await asyncio.sleep(ms / 1000)
