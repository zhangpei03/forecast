"""SSO 和 MCP Gateway 认证相关常量定义。"""

# ── SSO Cookie / 会话 Key 名称 ────────────────────────────────────────────────

SSO_TICKET = "_sso_ticket"   # SSO ticket 存储在 Cookie 中的键名
LDAP = "_sso_ldap"           # 保留字段（LDAP 账号）
USER = "_sso_user"           # 保留字段（用户信息）

# ── SSO API 响应字段名 ────────────────────────────────────────────────────────

SSO_ERRNO = "errno"          # 响应中的错误码字段
SSO_ERRNO_SUCCESS = 0        # errno=0 表示成功
SSO_ERRNO_ERROR = 1          # errno=1 表示失败
SSO_ERRMSG = "errmsg"        # 错误信息字段
SSO_DATA = "data"            # 业务数据字段
SSO_CODE = "code"            # 部分接口使用 code 而非 errno
SSO_MSG = "msg"              # 部分接口使用 msg 而非 errmsg
SSO_CODE_SUCCESS = 200       # code=200 表示成功

# ── MCP Gateway 请求 Header 名 ────────────────────────────────────────────────
# Starlette 会将所有 Header 名称统一转为小写

MCP_HEADER_X_AUTH_SOURCE = "x-auth-source"    # 值为 "MCP" 时走 MCP 认证流程
MCP_HEADER_X_USER_CONTEXT = "x-user-context"  # Base64 编码的用户上下文 JSON
MCP_HEADER_APP_ID = "appid"                   # MCP 应用 ID
MCP_HEADER_TIMESTAMP = "timestamp"            # 请求时间戳（毫秒），防重放
MCP_HEADER_RANDOM = "random"                  # 随机数，参与签名计算
MCP_HEADER_SIGNATURE = "signature"            # SHA-1 签名值

MCP_AUTH_SOURCE = "MCP"  # x-auth-source Header 的预期值（大写匹配）

# 防重放攻击时间窗口：5 分钟，允许合理的时钟漂移
MCP_SIGNATURE_VALID_WINDOW_MS = 5 * 60 * 1000
