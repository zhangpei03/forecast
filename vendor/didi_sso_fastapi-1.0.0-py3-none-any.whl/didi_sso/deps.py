"""FastAPI 依赖注入：获取当前登录用户。

用法::

    from fastapi import Depends
    from didi_sso import current_user, User

    @router.get("/example")
    async def example(user: User = Depends(current_user)):
        return {"ldap": user.ldap, "name": user.user_name}
"""
from fastapi import HTTPException

from .models import User
from .user_context import get_user


def current_user() -> User:
    """FastAPI 依赖函数：返回当前请求的登录用户。

    Raises:
        HTTPException 401: 用户未登录时抛出
    """
    user = get_user()
    if user is None:
        raise HTTPException(status_code=401, detail="未登录")
    return user
