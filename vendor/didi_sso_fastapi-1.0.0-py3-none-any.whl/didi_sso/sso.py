"""SSO 路由工厂：生成登录状态查询、登出、OAuth 回调三个端点。

用法::

    from didi_sso import SsoService, create_sso_router

    sso = SsoService(app_id="...", ...)
    app.include_router(create_sso_router(sso, prefix="/your-app/sso"))

生成的端点：
  GET {prefix}/auth/user-info  — 当前登录用户信息（供前端 Header 展示）
  GET {prefix}/logout-url      — 返回登出 URL 并清除本地 Cookie
  GET {prefix}/callback        — SSO OAuth 登录后的回调重定向
"""
from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, RedirectResponse

from ._logger import log_biz
from .sso_service import SsoService
from .user_context import get_user


def create_sso_router(sso_service: SsoService, prefix: str = "/sso") -> APIRouter:
    """创建 SSO 路由器，绑定到指定的 SsoService 实例。

    Args:
        sso_service: 已初始化的 SsoService 实例
        prefix:      路由前缀，默认 "/sso"；各项目按命名空间自定义

    Returns:
        配置好的 FastAPI APIRouter
    """
    router = APIRouter(prefix=prefix, tags=["SSO"])

    @router.get("/auth/user-info")
    async def get_user_info(request: Request):
        """返回当前登录用户的基本信息，供前端 Header 展示。"""
        user = get_user()
        if not user:
            return JSONResponse({"ldap": "", "user_name": "", "email": "", "department": ""})
        return JSONResponse({
            "ldap": user.ldap,
            "user_name": user.user_name,
            "email": user.email,
            "department": user.department,
        })

    @router.get("/logout-url")
    async def get_logout_url(request: Request):
        """返回 SSO 登出 URL，同时清除本地 ticket Cookie。

        Response: {"logoutUrl": "https://sso.example.com/logout?..."}
        """
        referer = request.headers.get("referer", "")
        logout_url = sso_service.get_logout_url(referer)
        log_biz("_sso_auth", level="DEBUG", action="logout_url")
        response = JSONResponse({"logoutUrl": logout_url})
        sso_service.remove_ticket_cookie(response)
        return response

    @router.get("/callback")
    async def callback(request: Request, jumpto: str = "/"):
        """SSO OAuth 登录回调，重定向到登录前访问的页面。

        SsoMiddleware 已在拦截阶段完成换票和写 Cookie，此处只做重定向。
        jumpto 默认 "/" 以防 SSO 服务端未回传该参数。
        """
        log_biz("_sso_auth", level="DEBUG", action="callback", uri=jumpto[:200])
        return RedirectResponse(url=jumpto, status_code=302)

    return router
