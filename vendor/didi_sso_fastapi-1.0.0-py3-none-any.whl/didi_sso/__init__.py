"""didi-sso-fastapi: DiDi 内部 SSO + MCP Gateway 认证中间件（FastAPI）。

快速接入::

    from didi_sso import SsoService, McpAuthService, SsoMiddleware, create_sso_router

    sso = SsoService(app_id="your_app_id", app_key="your_app_key",
                     sso_host="https://mis.diditaxi.com.cn")
    mcp = McpAuthService(mcp_app_id="your_mcp_app_id", mcp_secret_key="your_secret")

    app.add_middleware(SsoMiddleware, sso_service=sso, mcp_auth=mcp, enabled=True)
    app.include_router(create_sso_router(sso, prefix="/your-app/sso"))
"""
from .user_context import get_user, set_user, clear_user
from .models import User, McpUserContext
from .sso_service import SsoService
from .mcp_auth import McpAuthService
from .middleware import SsoMiddleware
from .deps import current_user
from .sso import create_sso_router

__version__ = "1.0.0"

__all__ = [
    # 用户上下文
    "get_user",
    "set_user",
    "clear_user",
    # 数据模型
    "User",
    "McpUserContext",
    # 核心服务
    "SsoService",
    "McpAuthService",
    # FastAPI 集成
    "SsoMiddleware",
    "current_user",
    "create_sso_router",
]
