"""MCP Gateway 签名认证服务。

认证流程（按顺序，任一步骤失败即 ValueError）：
  1. 校验必要 Header 全部存在（appid / timestamp / random / signature / x-user-context）
  2. 校验 appId 与配置值匹配
  3. 校验 SHA-1 签名：SHA1(appId + timestamp + random + secretKey)
  4. 解码 x-user-context（Base64 JSON）→ McpUserContext
  5. 校验 timestamp 在 5 分钟有效窗口内（防重放）
"""
import base64
import hashlib
import json
import time

from ._logger import log_biz
from .constants import (
    MCP_AUTH_SOURCE,
    MCP_HEADER_APP_ID,
    MCP_HEADER_RANDOM,
    MCP_HEADER_SIGNATURE,
    MCP_HEADER_TIMESTAMP,
    MCP_HEADER_X_AUTH_SOURCE,
    MCP_HEADER_X_USER_CONTEXT,
    MCP_SIGNATURE_VALID_WINDOW_MS,
)
from .models import McpUserContext, User


class McpAuthService:
    """MCP Gateway 请求的签名校验与用户提取服务。"""

    def __init__(self, *, mcp_app_id: str, mcp_secret_key: str) -> None:
        """
        Args:
            mcp_app_id:     MCP 应用 ID，来自配置文件
            mcp_secret_key: MCP 签名密钥，来自配置文件（勿硬编码）
        """
        self.mcp_app_id = mcp_app_id
        self.mcp_secret_key = mcp_secret_key

    def is_mcp_request(self, headers) -> bool:
        """判断请求是否来自 MCP Gateway（x-auth-source: MCP）。"""
        return headers.get(MCP_HEADER_X_AUTH_SOURCE, "").upper() == MCP_AUTH_SOURCE

    def check_mcp_auth(self, headers) -> User:
        """完整执行 MCP 签名认证，返回认证后的用户对象。

        Raises:
            ValueError: 任意校验步骤失败时抛出
        """
        app_id = headers.get(MCP_HEADER_APP_ID, "")
        timestamp_str = headers.get(MCP_HEADER_TIMESTAMP, "")
        random_val = headers.get(MCP_HEADER_RANDOM, "")
        signature = headers.get(MCP_HEADER_SIGNATURE, "")
        user_context_token = headers.get(MCP_HEADER_X_USER_CONTEXT, "")

        self._verify_base_params(app_id, timestamp_str, random_val, signature, user_context_token)
        self._verify_app_id(app_id)
        self._verify_signature(app_id, timestamp_str, random_val, signature)

        user_context = self._parse_user_context(user_context_token)
        self._validate_timestamp(user_context.timestamp)

        user = User()
        user.ldap = user_context.ldap
        user.user_name = user_context.user_name
        return user

    def _verify_base_params(self, app_id, timestamp_str, random_val, signature, user_context_token) -> None:
        if not all([app_id, timestamp_str, random_val, signature, user_context_token]):
            log_biz("_sso_mcp_auth", level="ERROR", errno=-1, errmsg="params missing", app_id=app_id)
            raise ValueError(f"MCP auth params missing, appId={app_id}")

    def _verify_app_id(self, app_id: str) -> None:
        if app_id != self.mcp_app_id:
            log_biz("_sso_mcp_auth", level="ERROR", errno=-1, errmsg="appId mismatch", app_id=app_id)
            raise ValueError(f"MCP appId mismatch, appId={app_id}")

    def _verify_signature(self, app_id: str, timestamp_str: str, random_val: str, signature: str) -> None:
        if not self.mcp_secret_key:
            log_biz("_sso_mcp_auth", level="ERROR", errno=-1, errmsg="secretKey not configured")
            raise ValueError("MCP secretKey not configured")
        raw = app_id + timestamp_str + random_val + self.mcp_secret_key
        expected = hashlib.sha1(raw.encode("utf-8")).hexdigest()
        if expected != signature:
            log_biz("_sso_mcp_auth", level="ERROR", errno=-1, errmsg="signature verification failed", app_id=app_id)
            raise ValueError(f"MCP signature verification failed, appId={app_id}")

    def _parse_user_context(self, token: str) -> McpUserContext:
        try:
            json_bytes = base64.b64decode(token)
            data = json.loads(json_bytes.decode("utf-8"))
            return McpUserContext.from_dict(data)
        except Exception as exc:
            log_biz("_sso_mcp_auth", level="ERROR", errno=-1, errmsg=f"user context parse failed: {str(exc)[:200]}")
            raise ValueError("MCP user context parse failed") from exc

    def _validate_timestamp(self, timestamp_ms: int) -> None:
        current_ms = int(time.time() * 1000)
        diff = abs(current_ms - timestamp_ms)
        if diff > MCP_SIGNATURE_VALID_WINDOW_MS:
            log_biz("_sso_mcp_auth", level="ERROR", errno=-1, errmsg="request expired", diff_ms=diff)
            raise ValueError(
                f"MCP request expired (diff={diff}ms, window={MCP_SIGNATURE_VALID_WINDOW_MS}ms)"
            )
