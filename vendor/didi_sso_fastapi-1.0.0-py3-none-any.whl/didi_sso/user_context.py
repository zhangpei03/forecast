"""基于 ContextVar 的请求级用户存储，等价于 Java 的 ThreadLocal<User>。

Python asyncio 中，每个协程拥有独立的 ContextVar 副本，不同请求之间天然隔离。
SsoMiddleware 在请求进入时调用 set_user()，请求完成后在 finally 块调用 clear_user()。
"""
from contextvars import ContextVar
from typing import Optional

from .models import User

_user_var: ContextVar[Optional[User]] = ContextVar("current_user", default=None)


def set_user(user: User) -> None:
    """将认证后的用户写入当前协程的 ContextVar（由 SsoMiddleware 调用）。"""
    _user_var.set(user)


def get_user() -> Optional[User]:
    """读取当前协程的登录用户；未认证时返回 None。"""
    return _user_var.get()


def clear_user() -> None:
    """清除当前协程的用户信息（由 SsoMiddleware 的 finally 块调用）。"""
    _user_var.set(None)
